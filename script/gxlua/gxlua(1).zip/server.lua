Server = Server or {}
Server.ServerStart = function ()
end
Server.ServerStop = function ()
	unilight.warn("ServerStop:需要做必要的卸载和存档操作,请在逻辑层重写这个函数")
end
